/********************************************************************************
* main.c: Interruptbaserad styrning av tv� lysdioder anslutna till pin 8 - 9
*         (PORTB0 - PORTB1) via nedtryckning av tryckknappar anslutna till 
*         pin 12 - 13 (PORTB4 - PORTB5).
********************************************************************************/
#include "header.h"

/********************************************************************************
* main: Initierar mikrodatorn vid start. Programmet h�lls sedan ig�ng s� l�nge
*       matningssp�nning tillf�rs. Toggling av lysdioderna sker via interrupts,
*       d�rav avsaknad av kod i while-satsen.
********************************************************************************/
int main(void)
{
   setup();

   while (1)
   {
   }

   return 0;
}

